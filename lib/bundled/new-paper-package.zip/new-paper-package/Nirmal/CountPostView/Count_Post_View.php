<?php
/**
 * Created by PhpStorm.
 * User: nirmal
 * Date: 30/04/2016
 * Time: 13:30
 */

namespace Nirmal\CountPostView;


class Count_Post_View
{

    protected $read_posts;
    public $handler;
    protected $count_key;
    protected $date_key = 'ntx_last_view_date';

    public function __construct( Count_Post_View_Interface $handler = null ) {

        // Defaults to cookie handler
        $this->handler = $handler ?: new Count_Post_View_Cookie;

    }


    public function get_unread_posts( $args = array() ) {

        $defaults = array(
            'post_type' => 'post',
            'post_status' => 'publish',
            'post__not_in' => $this->get_read_posts(),
            'fields' => 'ids',
            'posts_per_page' => -1,
            'orderby' => 'DESC'
        );

        $args = wp_parse_args( $args, $defaults );
        $args = apply_filters( 'ntx/unread_query_args', $args );

        $unread = new WP_Query( $args );

        if( $unread->found_posts == 0 ) {
            return array();
        }

        else {
            return $unread;
        }

    }

    public function get_read_posts() {

        return $this->read_posts;

    }

    protected function update_count_view($post_id, $negative = false){

        $count = get_post_meta($post_id, $this->count_key, true);

        if(empty($count) && $count != 0){
            delete_post_meta($post_id, $this->count_key);
            add_post_meta($post_id, $this->count_key, 0);
        }else{
            if($negative){
                $count--;
            }else{
                $count++;
            }
            update_post_meta($post_id, $this->count_key, $count);
        }


    }


    protected function update_last_view_date($post_id){

        $last_view_date = get_post_meta($post_id, $this->date_key, true);

        if(empty($last_view_date)){
            delete_post_meta($post_id, $this->date_key);
            add_post_meta($post_id, $this->date_key, time());
        }else{
            update_post_meta($post_id, $this->date_key, time());
        }

    }

    /**
     * @param $post_id integer
     * @return int
     */
    public function get_post_views($post_id){

        $count = get_post_meta($post_id, $this->count_key, true);

        if(empty($count)){
            delete_post_meta($post_id, $this->count_key);
            add_post_meta($post_id, $this->count_key, 0);
            return '';
        }

        $count = (int)$count;

        return $count;

    }


}