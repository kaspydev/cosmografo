<?php
/**
 * Created by PhpStorm.
 * User: nirmal
 * Date: 30/04/2016
 * Time: 13:32
 */

namespace Nirmal\CountPostView;


class Count_Post_View_Cookie extends Count_Post_View implements Count_Post_View_Interface
{

    protected $cookie_name;
    protected $read_posts;
    protected $expiry_cookie = 3600;    // 1 hour

    public function __construct() {
        $this->set_cookie_name();
        $this->set_read_posts();
        $this->set_count_key();
    }

    // auto call
    protected function set_count_key(){

        $count_key = 'ntx_post_views_count';
        $count_key = apply_filters( 'ntx/count_key', $count_key );
        $this->count_key = $count_key;

    }

    // auto call
    protected function set_cookie_name() {
        $cookie_name = sanitize_title_with_dashes( get_bloginfo('title') . '-ntx_read_posts' );
        $cookie_name = apply_filters( 'ntx/cookie_name', $cookie_name );
        $this->cookie_name = $cookie_name;
    }

    // auto call
    protected function set_read_posts() {
        if( !empty( $_COOKIE[$this->cookie_name] ) ) {
            $this->read_posts = $this->uncompress_data($_COOKIE[$this->cookie_name]);
        }
        else {
            $this->read_posts = array();
        }
    }


    // this is the method that will be called from application
    public function set_posts_as_read( $posts ) {

        if( is_numeric( $posts ) ) {
            $posts = array( $posts );
        }

        if( array_intersect( $this->read_posts, $posts ) == $posts ) {
            return ;
        }

        $this->read_posts = array_unique( array_merge( $this->read_posts, $posts ) );
        $cookie_value = $this->compress_data($this->read_posts);

        setcookie( $this->cookie_name, $cookie_value, time() + $this->expiry_cookie , COOKIEPATH, COOKIE_DOMAIN, false );
    }

    public function set_posts_as_unread( $posts ) {
        if( is_numeric( $posts ) ) {
            $posts = array( $posts );
        }

        $this->read_posts = array_diff( $this->read_posts, $posts );
        $cookie_value = $this->compress_data( $this->read_posts ) ;

        setcookie( $this->cookie_name, $cookie_value, time() + $this->expiry_cookie, COOKIEPATH, COOKIE_DOMAIN, false );

    }

    public function delete_read_posts() {

        if( isset( $_COOKIE[$this->cookie_name] ) ) {
            // set cookie as empty
            setcookie( $this->cookie_name, null , time() + $this->expiry_cookie, COOKIEPATH, COOKIE_DOMAIN, false );
            $this->read_posts = array();

        }
    }


    protected function compress_data($data = array()){

        $data = implode(',', $data);
        //$data = gzcompress($data);

        return $data;

    }

    protected function uncompress_data($data){

        //$data = gzuncompress($data);
        return explode(',', $data);

    }

    /*
     * post_id : The post id for which view and like is being tracked upon
     * decrease : if view count, decrease (unviewing) is disable (false)
     *            if like count, decrease (unlike) is enabled (true)
     * */
    public function set_count_views($post_id, $decrease = true){

        $this->update_last_view_date($post_id);

        // set post view count
        if(isset($_COOKIE[$this->cookie_name]) ){


            // if this particular id is not in cookie, go ahead and increase view number
            if(!in_array($post_id, $this->uncompress_data($_COOKIE[$this->cookie_name]) ) ){

                $this->update_count_view($post_id);

            }else{

                if($decrease){
                    // unliking post
                    $this->set_posts_as_unread($post_id);
                    $this->update_count_view($post_id, true);
                }

            }

        }else{

            $this->update_count_view($post_id);

        }


    }

    public function modify_cookie_name($name = ''){
        $this->cookie_name = $name;
        $this->set_read_posts();
    }

    public function modify_count_key($name = ''){
        $this->count_key = $name;
        $this->set_read_posts();
    }

    public function is_liked($post_id){

        if(array_key_exists($this->cookie_name , $_COOKIE)){

            if(in_array($post_id, $this->uncompress_data($_COOKIE[$this->cookie_name]) ) ){
                return true;
            }

        }

        return false;

    }



}