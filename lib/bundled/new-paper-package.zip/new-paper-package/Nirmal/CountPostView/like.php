<?php


/*
 * REQUIRES autoload file
 * */
require ( trailingslashit( plugin_dir_path(__FILE__ ) ). '../../vendor/autoload.php');

use Nirmal\CountPostView\Count_Post_View;


/*
 * ============================================================
 * Initialize global variable which holds POST VIEW COUNT HANDLER
 * */
add_action( 'plugins_loaded', 'new_paper_ntx_set_like_count_handler' );


function new_paper_ntx_set_like_count_handler() {

    global $ntx_like_count;
    $like_count_hanndler = 'Nirmal\CountPostView\Count_Post_View_Cookie';

    // if applied filters, class name should be a full namespace)
    apply_filters('ntx/view_count_handler', $like_count_hanndler);


    $like_count = new Count_Post_View(new $like_count_hanndler);

    $ntx_like_count = $like_count->handler;

    // Modify default key
    $ntx_like_count->modify_count_key('ntx_like_post_count');
    $ntx_like_count->modify_cookie_name('ntx_post_liked');


}

/*
 * ============================================================
 * Update the post view count and set cookie and all
 * */

add_action('wp_ajax_nopriv_new_paper_ntx_set_like_count', 'new_paper_ntx_set_like_count');
add_action('wp_ajax_new_paper_ntx_set_like_count', 'new_paper_ntx_set_like_count');


function new_paper_ntx_set_like_count() {
    global $ntx_like_count;

    // Only on single page : single post/page/attachment
    $post_id = (int)$_POST['post_id'];


    // set cokkie/meta info of viewed post
    $ntx_like_count->set_posts_as_read($post_id);

    // update the number of count the post has been viewed
    $ntx_like_count->set_count_views($post_id);

    $total_likes = $ntx_like_count->get_post_views($post_id);

    echo $total_likes;

    die();

}

/*
 * ============================================================
 * Register shorcode to display post view count
 * */

add_shortcode( 'ntx_like_count', 'new_paper_ntx_like_count_shortcode' );
function new_paper_ntx_like_count_shortcode( $atts ) {

    global $ntx_like_count;

    // Attributes
    extract( shortcode_atts(
            array(
                'post_id'      => ''        // TYPE: primary, success, info, warning, danger
            ), $atts )
    );

    if(empty($post_id)){
        global $post;
        $post_id = $post->ID;
    }

    return $ntx_like_count->get_post_views($post_id);

}
