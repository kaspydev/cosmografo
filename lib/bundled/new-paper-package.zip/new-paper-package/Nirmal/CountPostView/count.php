<?php

/*
 * STRUCTURE :
 * INTERFACE : Count_Post_View_Interface
 * AVAILABLE IMPLEMENTATIONS : Count_Post_View_Cookie (available) | Count_Post_View_Db (Future)
 * ACTUAL
 *
 * */


/*
 * REQUIRES autoload file
 * */
require ( trailingslashit( plugin_dir_path(__FILE__ ) ). '../../vendor/autoload.php');

use Nirmal\CountPostView\Count_Post_View;

/*
 * ============================================================
 * Initialize global variable which holds POST VIEW COUNT HANDLER
 * */
add_action( 'plugins_loaded', 'new_paper_ntx_set_view_count' );


function new_paper_ntx_set_view_count() {

    global $ntx_view_count;

    // We have only created cookie based system
    // If database persistance is needed, we need to create a new class possibly Count_Post_View_Database
    $view_count_hanndler = 'Nirmal\CountPostView\Count_Post_View_Cookie';

    // if applied filters, class name should be a full namespace)
    // Setting up filter named 'ntx/view_count_handler'
    apply_filters('ntx/view_count_handler', $view_count_hanndler);

    $view_count = new Count_Post_View(new $view_count_hanndler);
    $ntx_view_count = $view_count->handler;

}

/*
 * ============================================================
 * Update the post view count and set cookie and all
 * */

add_action( 'wp', 'new_paper_ntx_set_post_view_count' );

function new_paper_ntx_set_post_view_count() {
    global $ntx_view_count;

    // Only on single page : single post/page/attachment
    if( is_singular() ) {
        global $post;

        // set cokkie/meta info of viewed post
        $ntx_view_count->set_posts_as_read($post->ID);

        // update the number of count the post has been viewed
        $ntx_view_count->set_count_views($post->ID, false);
    }

}

/*
 * ============================================================
 * Register shorcode to display post view count
 * */

add_shortcode( 'ntx_view_count', 'new_paper_ntx_view_count_shortcode' );
function new_paper_ntx_view_count_shortcode( $atts ) {

    global $ntx_view_count;

    // Attributes
    extract( shortcode_atts(
            array(
                'post_id'      => ''        // TYPE: primary, success, info, warning, danger
            ), $atts )
    );

    if(empty($post_id)){
        global $post;
        $post_id = $post->ID;
    }

    return $ntx_view_count->get_post_views($post_id);

}







