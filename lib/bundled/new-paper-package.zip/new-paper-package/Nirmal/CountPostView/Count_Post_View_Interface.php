<?php
/**
 * Created by PhpStorm.
 * User: nirmal
 * Date: 30/04/2016
 * Time: 13:28
 */

namespace Nirmal\CountPostView;


interface Count_Post_View_Interface
{

    /**
     * @param int $posts : Post Id
     */
    public function set_posts_as_read( $posts );

    /**
     * @param int $posts : Post Id
     */
    public function set_posts_as_unread( $posts );

    /**
     * @return array
     */
    public function get_read_posts();

    /**
     * @return array
     */
    public function get_unread_posts();


    public function delete_read_posts();


    /**
     * @param int $post_id : Post Id
     */
    public function get_post_views($post_id);

    /**
     * @param int $post_id : Post Id
     */
    public function set_count_views($post_id);


    public function modify_cookie_name($name);

}