<?php
/*
Plugin Name:    New paper Package
Description:    Essential components for New Paper Wordpress theme.
Version:        1.0
Author:         Nirmal Thapa
Author URI:     http://hazesoft.co
License:        GPLv2 or later
*/


class New_Paper_Ntx_Package{

}

function pre($data = ''){
    echo '<pre>';
    print_r($data);
    echo '</pre>';
}

function preX($data = ''){
    echo '<pre>';
    var_dump($data);
    echo '</pre>';
}

/**
 * Radium installer
 */
require ( trailingslashit( plugin_dir_path(__FILE__ ) ). 'includes/radium_installer/init.php');

/*Count post view module*/
require ( trailingslashit( plugin_dir_path(__FILE__ ) ). 'Nirmal/CountPostView/count.php');

/*Count post like*/
require ( trailingslashit( plugin_dir_path(__FILE__ ) ). 'Nirmal/CountPostView/like.php');

/*Regsiter video custom post type*/
require ( trailingslashit( plugin_dir_path(__FILE__ ) ). 'includes/register_video.php');

/*Regsiter video custom post type*/
require ( trailingslashit( plugin_dir_path(__FILE__ ) ). 'includes/shortcodes.php');

/*Plugin settings*/
//require ( trailingslashit( plugin_dir_path(__FILE__ ) ). 'includes/plugin_settings.php');

/*Include all widgets*/
foreach ( glob( plugin_dir_path( __FILE__ ) . "widgets/*.php" ) as $file ) {
    require $file;
}






