<?php

// register widget
add_action( 'widgets_init', function() {
    register_widget( 'New_Paper_Ntx_Page_Linking' );
});

class New_Paper_Ntx_Page_Linking extends WP_Widget {


    function __construct()
    {
        parent::__construct(
            'new_paper_ntx_page_linking',               // Base ID
            esc_html__('New Paper : Page Linking ', 'new-paper'),   // Name
            array('description' => esc_html__('Allows to pick a page from the list to show in desired place', 'new-paper'),) // Args
        );
    }


    // The admin form for the widget


    function form( $instance )
    {

        global $post;

        $title       = !empty($instance['title']) ? $instance['title'] : esc_html__('Linked Page', 'new-paper');
        $select      = !empty($instance['select']) ? $instance['select'] : '';


        ?>

        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php esc_html_e('Title:', 'new-paper'); ?></label>
            <input class="widefat"
                   id="<?php echo $this->get_field_id('title'); ?>"
                   name="<?php echo $this->get_field_name('title'); ?>"
                   type="text"
                   value="<?php echo esc_attr($title); ?>">
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('select'); ?>"><?php esc_html_e('Allows to pick a page from the list to show in desired place', 'new-paper'); ?></label>
            <select class="widefat"
                    id="<?php echo $this->get_field_name('select'); ?>"
                    name="<?php echo $this->get_field_name('select'); ?>">
                <?php

                // WP_Query arguments
                $args = array (
                    'post_type'              => array( 'page' ),
                    'posts_per_page'        => -1
                );

                // The Query
                $query = new WP_Query( $args );

                // The Loop
                if ( $query->have_posts() ) {
                    while ( $query->have_posts() ) {
                        $query->the_post();

                        ?>
                        <option value="<?php echo esc_attr($post->post_name) ?>" <?php echo ($select == $post->post_name) ? 'selected="selected"' : '' ?>>
                            <?php echo ucfirst(esc_html(get_the_title())) ?>
                        </option>
                        <?php
                    }
                } else {
                    // no posts found
                }

                // Restore original Post Data
                wp_reset_postdata();

                ?>
            </select>
        </p>

        <?php

    }

    function update( $new_instance, $old_instance )
    {
        $instance = $old_instance;
        $instance['select'] = esc_sql( $new_instance['select'] );
        $instance['title'] = esc_sql( $new_instance['title']);
        return $instance;
    }


    function widget($args, $instance) {

        extract( $args );

        global $post;
        global $new_paper_helper;

        $slug       = $instance['select'];
        $title      = $instance['title'];

        // WP_Query arguments
        $args = array (
            'name'                   => $slug,
            'post_type'              => array( 'page' ),
        );

        // The Query
        $query = new WP_Query( $args );

        // The Loop
        if ( $query->have_posts() ) {



            while ( $query->have_posts() ) {
                $query->the_post();

                echo $before_widget;

                ?>

                <div class="about-intro">

                    <?php
                    echo $before_title;
                    echo esc_html($title);
                    echo $after_title;
                    ?>

                    <?php
                    $image_url = wp_get_attachment_url(get_post_thumbnail_id());
                    $image_url = aq_resize($image_url, 640, 330, true, true, true); // X2

                    ?>

                    <a href="<?php the_permalink() ?>">
                        <img data-original="<?php echo esc_url($image_url) ?>" src="<?php echo esc_url($image_url) ?>" alt="<?php echo esc_attr($title) ?>">
                    </a>

                    <p>
                        <?php echo esc_html($new_paper_helper->cut_words( get_post_meta(get_the_ID(), 'new_paper_ntx_lead_paragraph', true) , 170)); ?>
                    </p>

                </div>
                <?php

                echo $after_widget;

            }


            // Restore original Post Data
            wp_reset_postdata();

            ?>

            <?php

        }
    }

} // END: class HotTopics



?>