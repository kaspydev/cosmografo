<?php

class New_Paper_Ntx_Ads_Placeholder extends WP_Widget{

    function __construct() {

        // Add widget script
        add_action('admin_enqueue_scripts', array($this, 'scripts'));

        parent::__construct(
            'new_paper_ntx_ads_placeholder',               // Base ID
            esc_html__( 'New Paper : Ads Placeholder', 'new-paper' ),   // Name
            array( 'description' => esc_html__( 'External Link to be followed upon', 'new-paper' ), ) // Args
        );
    }

    public function scripts()
    {
        wp_enqueue_script( 'media-upload' );
        wp_enqueue_media();
        wp_enqueue_script('our_admin', get_template_directory_uri() . '/assets/js/our_admin.js', array('jquery'));
    }

    public function form( $instance ) {
        // Setting Default widget title if not set
        $ads_url        = empty($instance['ads_url']) ? '' : $instance['ads_url'];
        $image = ! empty( $instance['image'] ) ? $instance['image'] : '';
        ?>

        <p>
            <label for="<?php echo $this->get_field_id( 'ads_url' ); ?>"><?php echo esc_html__( 'Ads Banner Link', 'new-paper' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'ads_url' ); ?>" name="<?php echo $this->get_field_name( 'ads_url' ); ?>" type="text" value="<?php echo esc_attr( $ads_url ); ?>">
        </p>

        <p>
            <?php
            if(!empty($image)){
                ?>
                <img class="widefat" src="<?php echo esc_url($image) ?>" alt="<?php echo esc_html__('Ads Banner', 'new-paper') ?>">
                <?php
            }
            ?>
            <input type="hidden" class="widefat" id="<?php echo $this->get_field_id( 'image' ); ?>" name="<?php echo $this->get_field_name( 'image' ); ?>" type="text" value="<?php echo esc_url( $image ); ?>" />
            <button class="upload_image_button button button-primary">Upload Ads Banner</button>
        </p>

        <?php
    }

    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['ads_url']    = ( ! empty( $new_instance['ads_url'] ) ) ? strip_tags( $new_instance['ads_url'] ) : '';
        $instance['image'] = ( ! empty( $new_instance['image'] ) ) ? $new_instance['image'] : '';

        return $instance;
    }

    public function widget( $args, $instance ) {

        echo $args['before_widget'];
        ?>
        <div class="ads-area">
            <a href="<?php echo esc_url($instance['ads_url']) ?>" target="_blank">
                <img data-original="<?php echo esc_url($instance['image']) ?>" src="<?php echo esc_url($instance['image']) ?>" alt="<?php echo esc_html__('Ads Banner', 'new-paper') ?>">
            </a>
        </div>
        <?php
        echo $args['after_widget'];

    }

}


// Register Widget
add_action('widgets_init', 'new_paper_ntx_placeholder_widget_init');

// register widget
function new_paper_ntx_placeholder_widget_init(){

    register_widget('New_Paper_Ntx_Ads_Placeholder');

}

