<?php
/*
Plugin Name: Hot Topics
Plugin URI: http://www.weddingideasmag.com
Description: Use this widget to choose an array of posts snippets to show
Version: 1.0)
Author: James Payne
Author URI: http://www.bluntcreative.co.uk
License: GPL2
*/

// register widget
add_action( 'widgets_init', function() {
    register_widget( 'New_Paper_Ntx_Highlight_Post' );
});

class New_Paper_Ntx_Highlight_Post extends WP_Widget {


    function __construct()
    {
        parent::__construct(
            'new_paper_ntx_highlight_post',               // Base ID
            esc_html__('New Paper : Post Linking ', 'new-paper'),   // Name
            array('description' => esc_html__('Allows to pick a post from the list to show in desired place', 'new-paper'),) // Args
        );
    }


    // The admin form for the widget


    function form( $instance )
    {

        global $post;

        $title       = !empty($instance['title']) ? $instance['title'] : esc_html__('Highlighted Post', 'new-paper');
        $select      = !empty($instance['select']) ? $instance['select'] : '';


        ?>

        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php esc_html_e('Title:', 'new-paper'); ?></label>
            <input class="widefat"
                   id="<?php echo $this->get_field_id('title'); ?>"
                   name="<?php echo $this->get_field_name('title'); ?>"
                   type="text"
                   value="<?php echo esc_attr($title); ?>">
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('select'); ?>"><?php esc_html_e('Select a post to display in sdidebar as highlighted post:', 'new-paper'); ?></label>
            <select class="widefat"
                    id="<?php echo $this->get_field_name('select'); ?>"
                    name="<?php echo $this->get_field_name('select'); ?>">
                <?php

                // WP_Query arguments
                $args = array (
                    'post_type'              => array( 'post' ),
                );

                // The Query
                $query = new WP_Query( $args );

                // The Loop
                if ( $query->have_posts() ) {
                    while ( $query->have_posts() ) {
                        $query->the_post();

                        ?>
                        <option value="<?php echo esc_attr($post->post_name) ?>" <?php echo ($select == $post->post_name) ? 'selected="selected"' : '' ?>>
                            <?php echo ucfirst(esc_html(get_the_title())) ?>
                        </option>
                        <?php
                    }
                } else {
                    // no posts found
                }

                // Restore original Post Data
                wp_reset_postdata();

                ?>
            </select>
        </p>

        <?php

    }

    function update( $new_instance, $old_instance )
    {
        $instance = $old_instance;
        $instance['select'] = esc_sql( $new_instance['select'] );
        $instance['title'] = esc_sql( $new_instance['title']);
        return $instance;
    }


    function widget($args, $instance) {

        global $post;
        global $new_paper_helper;

        $slug       = $instance['select'];
        $title      = $instance['title'];

        // WP_Query arguments
        $args = array (
            'name'                   => $slug,
            'post_type'              => array( 'post' ),
        );

        // The Query
        $query = new WP_Query( $args );

        // The Loop
        if ( $query->have_posts() ) {
            while ( $query->have_posts() ) {
                $query->the_post();
                ?>
                <div class="side-post">
                    <div class="post-type-kansas">

                        <figure class="post-image">
                            <?php
                            $image_url = wp_get_attachment_url(get_post_thumbnail_id(get_the_ID()));
                            $image_url = aq_resize($image_url, 680, 496, true, true, true );
                            ?>
                            <a href="<?php the_permalink() ?>">
                                <img data-original="<?php echo esc_url($image_url) ?>" src="<?php echo esc_url($image_url) ?>" alt="<?php the_title() ?>">
                            </a>

                            <?php
                            $new_paper_helper->review_badge();
                            ?>

                            <!-- end circle -->
                        </figure>

                        <div class="post-content">

                            <?php
                            $categories = get_the_category();
                            foreach ($categories as $category) {
                                ?>
                                <a class="category-link"
                                   href="<?php echo esc_url(get_category_link($category->term_id)) ?>">
                                <span class="label label-yellow category">
                                    <?php echo esc_html($category->name) ?>
                                </span>
                                </a>
                                <?php
                            }

                            ?>

                            <h4 class="post-title">
                                <a href="<?php the_permalink() ?>"><?php the_title() ?></a>
                            </h4>

                            <?php
                            $new_paper_helper->the_author('', 32);
                            $new_paper_helper->the_time();
                            ?>

                        </div>

                        <!-- end post-content -->
                    </div>
                    <!-- end post-type-kansas -->
                </div>

                <?php
            }
        } else {
            // no posts found
        }

        // Restore original Post Data
        wp_reset_postdata();

        ?>

        <?php

    }

} // END: class HotTopics



?>