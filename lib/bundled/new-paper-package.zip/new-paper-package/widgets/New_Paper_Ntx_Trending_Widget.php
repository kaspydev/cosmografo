<?php

class New_Paper_Ntx_Trending_Widget extends WP_Widget
{

    function __construct()
    {
        parent::__construct(
            'new_paper_ntx_trending_widget',               // Base ID
            esc_html__('New Paper : Trending Post', 'new-paper'),   // Name
            array('description' => esc_html__('Displays Trending Posts', 'new-paper'),) // Args
        );
    }

    public function form($instance)
    {
        // Setting Default widget title if not set
        $title       = !empty($instance['title']) ? $instance['title'] : esc_html__('Tredning Posts', 'new-paper');
        $posts_count = empty($instance['posts_count']) ? 3 : (int)$instance['posts_count'];
        $mode        = empty($instance['mode']) ? 'reddish' : $instance['mode'];
        ?>

        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php esc_html_e('Title:', 'new-paper'); ?></label>
            <input class="widefat"
                   id="<?php echo $this->get_field_id('title'); ?>"
                   name="<?php echo $this->get_field_name('title'); ?>"
                   type="text"
                   value="<?php echo esc_attr($title); ?>">
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('posts_count'); ?>"><?php esc_html_e('Number of posts:', 'new-paper'); ?></label>
            <input class="widefat"
                   id="<?php echo $this->get_field_id('posts_count'); ?>"
                   name="<?php echo $this->get_field_name('posts_count'); ?>"
                   type="text"
                   value="<?php echo esc_attr($posts_count); ?>">
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('mode'); ?>"><?php esc_html_e('Display Mode:', 'new-paper'); ?></label>
            <select class="widefat"
                    id="<?php echo $this->get_field_id('mode'); ?>"
                    name="<?php echo $this->get_field_name('mode'); ?>">

                <option <?php echo ($mode == 'reddish')? 'selected' : ''?> value="reddish">Reddish Mode</option>
                <option <?php echo ($mode == 'grey')? 'selected' : ''?> value="grey">Greyish Mode</option>

            </select>
        </p>

        <?php
    }

    public function update($new_instance, $old_instance)
    {
        $instance = array();
        $instance['title'] = (!empty($new_instance['title'])) ? strip_tags($new_instance['title']) : '';
        $instance['posts_count'] = (!empty($new_instance['posts_count'])) ? strip_tags($new_instance['posts_count']) : '';
        $instance['mode'] = (!empty($new_instance['mode'])) ? strip_tags($new_instance['mode']) : '';

        return $instance;
    }

    public function widget($args, $instance)
    {

        global $new_paper_helper;


        $max_number_of_posts = $instance['posts_count'];
        $mode = $instance['mode'];

        $post_ids = $new_paper_helper->is_popular('', true);

        if(!empty($post_ids)  && count($post_ids)){

            ?>

            <div class="<?php echo ($mode == 'reddish')? 'trend-posts' : 'popular-celebreties' ?>">

            <h3 class="title"><?php echo strtoupper(esc_html($instance['title'])); ?></h3>

            <?php

            $counter = 1;


            foreach ($post_ids as $post_id) {

                if($counter <= $max_number_of_posts){

                    $query_args = array(
                        'p' => $post_id, // id of a page, post, or custom type
                    );

                    $read_query = new WP_Query($query_args);


                    if ($read_query->have_posts()) {

                        while ($read_query->have_posts()): $read_query->the_post();
                            if($mode == 'reddish'){
                                ?>
                                <div class="post">
                                    <span class="number"><?php echo $counter ?></span>

                                    <small class="trending-post-cat"><?php echo get_the_category_list(' | ', '', get_the_ID()) ?></small>

                                    <h4 class="category trending-post-title">
                                        <a href="<?php the_permalink() ?>">
                                            <?php echo esc_html($new_paper_helper->cut_words(get_the_title(), 40)) ?>
                                        </a>
                                    </h4>
                                </div>
                                <?php
                            }else{

                                $image_url = wp_get_attachment_url(get_post_thumbnail_id());
                                $image_url = aq_resize($image_url, 70, 70, true, true);

                                ?>
                                <figure>
                                    <a href="<?php the_permalink() ?>">
                                        <img data-original="<?php echo esc_url($image_url) ?>" src="<?php echo esc_url($image_url) ?>" alt="<?php the_title() ?>">
                                    </a>
                                    <span>0<?php echo $counter ?></span>
                                    <figcaption>
                                        <h4>
                                            <a href="<?php the_permalink() ?>">
                                                <?php echo esc_html($new_paper_helper->cut_words(get_the_title(), 15)) ?>
                                            </a>
                                        </h4>

                                        <a href="<?php the_permalink() ?>">
                                            <?php echo esc_html($new_paper_helper->cut_words(get_the_excerpt(), 35)) ?>
                                        </a>

                                    </figcaption>
                                </figure>
                                <?php

                            }

                        endwhile;

                    }
                    wp_reset_postdata();

                }else{
                    break;
                }

                $counter++;

            }


        }

        ?>
        </div>
        <?php
    }

}


// Register Widget
add_action('widgets_init', 'new_paper_ntx_trending_widget_init');

// register widget
function new_paper_ntx_trending_widget_init(){

    register_widget('New_Paper_Ntx_Trending_Widget');

}

