<?php

// register widget
add_action( 'widgets_init', function() {
    register_widget( 'New_Paper_Ntx_Popular_Tags' );
});

class New_Paper_Ntx_Popular_Tags extends WP_Widget
{
    public function __construct()
    {
        parent::__construct(
            'new_paper_ntx_popular_tags',
            esc_html__('New Paper : Popular Tags', 'new-paper'),
            array(
                'description' => esc_html__('Displays popular tags in Descending order. Based on tags associated with posts', 'new-paper')
            )
        );
    }

    public function form( $instance ) {
        // Setting Default widget title if not set
        $title          = !empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'Popular Tags', 'new-paper' );
        $max            = !empty( $instance['max'] ) ? $instance['max'] : 0;
        ?>

        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php echo esc_html__( 'Title:', 'new-paper' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'max' ); ?>"><?php echo esc_html__( 'Maximum number of tags to disaplay', 'new-paper' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'max' ); ?>" name="<?php echo $this->get_field_name( 'max' ); ?>" type="text" value="<?php echo esc_attr( $max ); ?>">
        </p>

        <?php
    }

    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title']      = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
        $instance['max']      = ( ! empty( $new_instance['max'] ) ) ? strip_tags( $new_instance['max'] ) : '';

        return $instance;
    }

    public function widget( $args, $instance )
    {

        extract($args);

        $title  = $instance['title'];
        $max  = $instance['max'];
        ?>

        <?php
        echo $before_widget;
        echo $before_title.$title.$after_title;

        $tags = get_terms(array(
            'taxonomy'  => 'post_tag',
            'orderby'   => 'count',
            'order'     => 'DESC',
            'hide_empty' => false,
            'number'     => $max
        ));


        ?>

        <ul class="popular-tags">
            <?php

            if(count($tags)){
                foreach($tags as $tag){

                    ?>
                    <li>
                        <a href="<?php echo esc_url(get_tag_link($tag->term_id)) ?>" title="<?php echo esc_attr($tag->name) ?>">
                            <?php echo esc_html($tag->name) ?>
                        </a>
                    </li>
                    <?php

                }
            }
            ?>
        </ul>

        <?php

        echo $after_widget;

    }

}

