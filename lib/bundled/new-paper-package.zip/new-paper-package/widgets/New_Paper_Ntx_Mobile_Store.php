<?php

// register widget
add_action( 'widgets_init', function() {
    register_widget( 'New_Paper_Ntx_Mobile_Store' );
});

class New_Paper_Ntx_Mobile_Store extends WP_Widget
{
    public function __construct()
    {
        parent::__construct(
            'new_paper_ntx_mobile_store',
            esc_html__('New Paper : Mobile Store Link', 'new-paper'),
            array(
                'description' => esc_html__('Link your site to Mobile application store', 'new-paper')
            )
        );
    }

    public function form( $instance ) {
        // Setting Default widget title if not set
        $title          = !empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'Mobile Applications', 'new-paper' );
        $apple_link           = !empty( $instance['apple_link'] ) ? $instance['apple_link'] : '';
        $google_link           = !empty( $instance['google_link'] ) ? $instance['google_link'] : '';
        $description    = !empty( $instance['description'] ) ? $instance['description'] : '';

        ?>

        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php echo esc_html__( 'Title:', 'new-paper' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>

        <p>
            <label for="<?php echo $this->get_field_id('apple_link'); ?>"><?php esc_html_e('Apple store download link:', 'new-paper'); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'apple_link' ); ?>" name="<?php echo $this->get_field_name( 'apple_link' ); ?>" type="text" value="<?php echo esc_attr( $apple_link ); ?>">
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'google_link' ); ?>"><?php echo esc_html__( 'App Donwload Link', 'new-paper' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'google_link' ); ?>" name="<?php echo $this->get_field_name( 'google_link' ); ?>" type="text" value="<?php echo esc_attr( $google_link ); ?>">
        </p>

        <p>
            <label for="<?php echo $this->get_field_id( 'description' ); ?>"><?php echo esc_html__( 'Description:', 'new-paper' ); ?></label>
            <textarea rows="8" class="widefat" id="<?php echo $this->get_field_id( 'description' ); ?>" name="<?php echo $this->get_field_name( 'description' ); ?>"><?php echo esc_attr( $description ); ?></textarea>
        </p>


        <?php
    }

    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title']      = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';
        $instance['google_link']      = ( ! empty( $new_instance['google_link'] ) ) ? strip_tags( $new_instance['google_link'] ) : '';
        $instance['apple_link']      = ( ! empty( $new_instance['apple_link'] ) ) ? strip_tags( $new_instance['apple_link'] ) : '';
        $instance['description']      = ( ! empty( $new_instance['description'] ) ) ? strip_tags( $new_instance['description'] ) : '';

        return $instance;
    }

    public function widget( $args, $instance )
    {


        extract($args);

        $title  = $instance['title'];
        $apple_link  = $instance['apple_link'];
        $google_link  = $instance['google_link'];
        $description  = $instance['description'];

        ?>

        <?php
        echo $before_widget;

        echo $before_title.$title.$after_title;

        ?>
        <div class="mobile-app">
            <p>
                <?php echo esc_html($description) ?>
            </p>

            <?php
            if(!empty($apple_link)){
                ?>
                <a href="<?php echo esc_url($apple_link) ?>" target="_blank">
                    <img src="<?php echo get_template_directory_uri() ?>/assets/images/icon-appstore.png" alt="<?php _e('Apple Store', 'new-paper') ?>">
                </a>
                <?php
            }

            if(!empty($google_link)){
                ?>
                <a href="<?php echo esc_url($google_link) ?>" target="_blank">
                    <img src="<?php echo get_template_directory_uri() ?>/assets/images/icon-googleplay.png" alt="<?php _e('Google Play Store', 'new-paper') ?>">
                </a>
                <?php
            }
            ?>

        </div>
        <?php

        echo $after_widget;

    }

}

