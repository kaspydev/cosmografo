<?php

class New_Paper_Ntx_date_Widget extends WP_Widget{

    function __construct() {
        parent::__construct(
            'new_paper_ntx_date_class',               // Base ID
            esc_html__( 'New Paper : Current Date', 'new-paper' ),   // Name
            array( 'description' => esc_html__( 'Displays the current date', 'new-paper' ), ) // Args
        );
    }

    public function form( $instance ) {
        // Setting Default widget title if not set
        $format    = empty($instance['format']) ? 'l, F d, Y' : $instance['format'];
        ?>

        <p>
            <label for="<?php echo $this->get_field_id( 'format' ); ?>"><?php esc_html_e( 'Date Format', 'new-paper' ); ?></label>
            <input type="text" class="widefat" id="<?php echo $this->get_field_id( 'format' ); ?>" name="<?php echo $this->get_field_name( 'format' ); ?>" value="<?php echo esc_html($format) ?>">
            <span>
                <?php echo esc_html__('For complete date format list, visit ', 'new-paper') ?>
                <a href="http://php.net/manual/en/datetime.formats.date.php" target="_blank"><?php echo esc_html__('here','new-paper') ?></a>
            </span>
        </p>

        <?php
    }

    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['format']          = ( ! empty( $new_instance['format'] ) ) ?  $new_instance['format']: '';

        return $instance;
    }

    public function widget( $args, $instance ) {

        $format = (empty($instance['format']))? 'l, F d, Y' : $instance['format'];

        echo $args['before_widget'];

        echo $args['before_title'];

        echo $args['after_title'];

        echo '<span class="date">'. date(esc_html($format), time()) . '</span>';

        echo $args['after_widget'];

    }
}

// Register Widget
add_action('widgets_init', 'new_paper_ntx_date_widget_init');

// register widget
function new_paper_ntx_date_widget_init(){

    register_widget('New_Paper_Ntx_date_Widget');

}

