<?php
/*
Plugin Name: Hot Topics
Plugin URI: http://www.weddingideasmag.com
Description: Use this widget to choose an array of posts snippets to show
Version: 1.0)
Author: James Payne
Author URI: http://www.bluntcreative.co.uk
License: GPL2
*/

// register widget
add_action( 'widgets_init', function() {
    register_widget( 'New_Paper_Ntx_Featured_Categories' );
});

class New_Paper_Ntx_Featured_Categories extends WP_Widget {


    function __construct()
    {
        parent::__construct(
            'new_paper_ntx_featured_categories_widget',               // Base ID
            esc_html__('New Paper : Featured Categories', 'new-paper'),   // Name
            array('description' => esc_html__('Displays Selected Categories', 'new-paper'),) // Args
        );
    }


    // The admin form for the widget


    function form( $instance )
    {

        $title       = !empty($instance['title']) ? $instance['title'] : esc_html__('Featured Categories', 'new-paper');
        $select      = !empty($instance['select']) ? $instance['select'] : '';

        $_categories = get_terms(array(
            'taxonomy'  => 'category',
            'orderby'   => 'count',
            'order'     => 'DESC',
            'hide_empty' => false,
        ));

        ?>
        <p>
            <label for="<?php echo $this->get_field_id('title'); ?>"><?php esc_html_e('Title:', 'new-paper'); ?></label>
            <input class="widefat"
                   id="<?php echo $this->get_field_id('title'); ?>"
                   name="<?php echo $this->get_field_name('title'); ?>"
                   type="text"
                   value="<?php echo esc_attr($title); ?>">
        </p>

        <p>

            <label for="<?php echo $this->get_field_id('select'); ?>"><?php esc_html_e('Select Category to be displayed:', 'new-paper'); ?></label>

            <select class="widefat"
                    size="10"
                    multiple="multiple"
                    id="<?php echo $this->get_field_name('select'); ?>"
                    name="<?php echo $this->get_field_name('select'); ?>[]">


                <?php

                if(count($_categories)){
                    if(!is_array($select)){
                        $select = array();
                    }
                    foreach($_categories as $_category){
                        ?>
                        <option value="<?php echo esc_attr($_category->slug) ?>" <?php echo in_array( $_category->slug, $select) ? 'selected="selected"' : '' ?>>
                            <?php echo ucfirst(esc_html($_category->name)) ?>
                            [ <?php echo sprintf( _n( '%s Post', '%s Posts', $_category->count, 'new-paper' ), $_category->count) ?> ]
                        </option>
                        <?php
                    }
                }
                ?>

            </select>


        </p>

        <?php


    }

    function update( $new_instance, $old_instance )
    {
        $instance = $old_instance;
        $instance['select'] = esc_sql( $new_instance['select'] );
        $instance['title'] = esc_sql( $new_instance['title']);
        return $instance;
    }


    function widget($args, $instance) {

        $categories = $instance['select'];
        $title      = $instance['title'];

        if(count($categories)){

            ?>

            <div class="trend-posts">

            <h3 class="title"><?php echo strtoupper(esc_html($title)); ?></h3>

            <?php

            $counter = 1;


            foreach ($categories as $category) {

                $category = get_category_by_slug($category);

                ?>

                <div class="post">
                    <span class="number"><?php echo $counter ?></span>

                    <small class="trending-post-cat">
                        <a href="<?php echo esc_url(get_category_link($category->term_id)) ?>">

                            <?php echo esc_html($category->name) ?>

                        </a>
                    </small>

                    <h4 class="category trending-post-title">
                        <a href="<?php echo esc_url(get_category_link($category->term_id)) ?>">
                            <?php echo esc_html($category->description) ?>
                        </a>
                    </h4>
                </div>
                <?php

                $counter++;

            }


        }

        ?>
        </div>
        <?php

    }

} // END: class HotTopics



?>