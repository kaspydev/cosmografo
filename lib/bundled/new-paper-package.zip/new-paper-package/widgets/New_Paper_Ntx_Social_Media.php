<?php

// register widget
add_action( 'widgets_init', function() {
    register_widget( 'New_Paper_Ntx_Social_Medda' );
});

class New_Paper_Ntx_Social_Medda extends WP_Widget
{
    public function __construct()
    {
        parent::__construct(
            'new_paper_ntx_popular_social_media',
            esc_html__('New Paper : Social Site Linking', 'new-paper'),
            array(
                'description' => esc_html__('Link your site to your social site', 'new-paper')
            )
        );
    }

    public function form( $instance ) {
        // Setting Default widget title if not set
        $title          = !empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'Social Media', 'new-paper' );

        ?>

        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php echo esc_html__( 'Title:', 'new-paper' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>


        <?php
    }

    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title']      = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

        return $instance;
    }

    public function widget( $args, $instance )
    {

        global $new_paper_helper;

        extract($args);

        $title  = $instance['title'];
        ?>

        <?php
        echo $before_widget;

        echo $before_title.$title.$after_title;

        $new_paper_helper->the_social_connection();

        echo $after_widget;

    }

}

