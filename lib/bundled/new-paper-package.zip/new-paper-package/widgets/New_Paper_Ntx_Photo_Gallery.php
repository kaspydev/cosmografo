<?php

// register widget
add_action( 'widgets_init', function() {
    register_widget( 'New_Paper_Ntx_Photo_Gallery' );
});

class New_Paper_Ntx_Photo_Gallery extends WP_Widget
{
    public function __construct()
    {
        parent::__construct(
            'new_paper_ntx_photo_gallery',
            esc_html__('New Paper : Photo gallery', 'new-paper'),
            array(
                'description' => esc_html__('Photo Gallery: Create photo gallery for footer thorugh apparance > theme options.', 'new-paper')
            )
        );
    }

    public function form( $instance ) {
        // Setting Default widget title if not set
        $title          = !empty( $instance['title'] ) ? $instance['title'] : esc_html__( 'Photo Gallery', 'new-paper' );
        ?>

        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php echo esc_html__( 'Title:', 'new-paper' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>

        <?php
    }

    public function update( $new_instance, $old_instance ) {
        $instance = array();
        $instance['title']      = ( ! empty( $new_instance['title'] ) ) ? strip_tags( $new_instance['title'] ) : '';

        return $instance;
    }

    public function widget( $args, $instance )
    {

        extract($args);

        if(function_exists('ot_get_option')){
            $images = ot_get_option('new_paper_ntx_footer_photo_gallery');
        }else{
            $images = '';
        }

        $title  = $instance['title'];
        ?>

        <?php
        echo $before_widget;

            echo $before_title.$title.$after_title;

        ?>

        <ul class="gallery zoom-gallery">
            <?php
            $images = explode(',', $images);
            if(count($images)){
                foreach($images as $image){
                    $original_image = wp_get_attachment_url($image);
                    $thumbnail_image = aq_resize($original_image, 440, 310, true, true, true); // X5
                    ?>
                    <li>
                        <a href="<?php echo esc_url($original_image) ?>" title="<?php _e('Image', 'new-paper') ?>">
                        <img data-original="<?php echo esc_url($thumbnail_image) ?>" src="<?php echo esc_url($thumbnail_image) ?>" alt="<?php _e('Image', 'new-paper') ?>"></a>
                    </li>
                    <?php
                }
            }
            ?>
        </ul>

        <?php

        echo $after_widget;

    }

}

