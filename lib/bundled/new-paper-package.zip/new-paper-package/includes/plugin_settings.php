<?php


function new_paper_ntx_extended_option_file(){

    // Theme Options
    add_filter( ot_settings_id() . '_args', 'new_paper_ntx_extended_theme_options');

    function new_paper_ntx_extended_theme_options($custom_settings){

        // Adding sections
        if(isset($custom_settings['sections'])){

            $custom_settings['sections'][] = array(

                'id'          => 'generalx',
                'title'       => esc_html__('Generalx', 'new-paper')

            );

        }


        // Adding settings
        if ( isset( $custom_settings['settings'] ) ) {

            // If the Ajax loader plugin is activated
            // Ajax Load More - Plugin
            $custom_settings['settings'][] = array(
                'id'          => 'enable_infinte_news',
                'std'         => 'off',
                'label'       => esc_html__( 'Enable infinite news in Blog page?', 'mag' ),
                'type'        => 'on-off',
                'section'     => 'generalx'
            );

        }

        return $custom_settings;
    }

}

add_action( 'after_setup_theme', 'new_paper_ntx_extended_option_file' );