<?php

/*
 * ALERT BOX
 * */
function new_paper_ntx_alert_box( $atts , $content = null ) {

    // Attributes
    $atts = shortcode_atts(
        array(
            'type' => 'info',
        ),
        $atts
    );

    extract($atts);


    return "<div class='alert alert-".esc_attr($type)."' role='alert'>
                $content
            </div>";


}
add_shortcode( 'alert', 'new_paper_ntx_alert_box' );

/*
 * BOOTSTRAP PANEL BOX
 * */
function new_paper_ntx_panel_box( $atts , $content = null ) {

    // Attributes
    extract( shortcode_atts(
            array(
                'type'      => 'info',        // TYPE: primary, success, info, warning, danger
                'heading'   => 'This is heading'
            ), $atts )
    );


    return "<div class='clearfix'></div><div class='panel panel-".esc_attr($type)."'>
            <div class = 'panel-heading'>
                $heading
            </div>
            <div class='panel-body'>
                $content
            </div>
        </div>";

}
add_shortcode( 'panel', 'new_paper_ntx_panel_box' );

/*
 * BOOTSTRAP PANEL BOX
 * */
function new_paper_ntx_label( $atts ) {

    // Attributes
    extract( shortcode_atts(
            array(
                'type'      => 'info',        // TYPE: primary, success, info, warning, danger
                'text'     => 'Label text'
            ), $atts )
    );


    return "<span class='label label-".$type."'>$text</span>";

}
add_shortcode( 'label', 'new_paper_ntx_label' );

