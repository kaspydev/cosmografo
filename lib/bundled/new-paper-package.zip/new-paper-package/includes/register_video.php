<?php

// Register Custom Post Type
function new_paper_ntx_create_video() {

    $labels = array(
        'name'                  => _x( 'Videos', 'Post Type General Name', 'new-paper' ),
        'singular_name'         => _x( 'Video', 'Post Type Singular Name', 'new-paper' ),
        'menu_name'             => __( 'Video', 'new-paper' ),
        'name_admin_bar'        => __( 'Video', 'new-paper' ),
        'archives'              => __( 'Video Archives', 'new-paper' ),
        'parent_item_colon'     => __( 'Parent Video:', 'new-paper' ),
        'all_items'             => __( 'All Videos', 'new-paper' ),
        'add_new_item'          => __( 'Add New Video', 'new-paper' ),
        'add_new'               => __( 'Add New', 'new-paper' ),
        'new_item'              => __( 'New Video', 'new-paper' ),
        'edit_item'             => __( 'Edit Video', 'new-paper' ),
        'update_item'           => __( 'Update Video', 'new-paper' ),
        'view_item'             => __( 'View Video', 'new-paper' ),
        'search_items'          => __( 'Search Video', 'new-paper' ),
        'not_found'             => __( 'Not found', 'new-paper' ),
        'not_found_in_trash'    => __( 'Not found in Trash', 'new-paper' ),
        'featured_image'        => __( 'Cover Image', 'new-paper' ),
        'set_featured_image'    => __( 'Set cover image', 'new-paper' ),
        'remove_featured_image' => __( 'Remove cover image', 'new-paper' ),
        'use_featured_image'    => __( 'Use as cover image', 'new-paper' ),
        'insert_into_item'      => __( 'Insert into Video', 'new-paper' ),
        'uploaded_to_this_item' => __( 'Uploaded to this Video', 'new-paper' ),
        'items_list'            => __( 'Videos list', 'new-paper' ),
        'items_list_navigation' => __( 'Videos list navigation', 'new-paper' ),
        'filter_items_list'     => __( 'Filter Videos list', 'new-paper' ),
    );
    $rewrite = array(
        'slug'                  => 'video',
        'with_front'            => true,
        'pages'                 => true,
        'feeds'                 => true,
    );
    $args = array(
        'label'                 => __( 'Video', 'new-paper' ),
        'description'           => __( 'New Paper Video', 'new-paper' ),
        'labels'                => $labels,
        'supports'              => array( 'title', 'thumbnail', ),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'menu_position'         => 5,
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => 'video',
        'exclude_from_search'   => false,
        'publicly_queryable'    => true,
        'rewrite'               => $rewrite,
        'capability_type'       => 'page',
    );
    register_post_type( 'new_paper_ntx_video', $args );

}
add_action( 'init', 'new_paper_ntx_create_video', 0 );

/*Register taxonoly related to video  [category type] */
// Register Custom Taxonomy
function regsiter_new_paper_ntx_video_category() {

    $labels = array(
        'name'                       => _x( 'Categorys', 'Taxonomy General Name', 'new-paper' ),
        'singular_name'              => _x( 'Category', 'Taxonomy Singular Name', 'new-paper' ),
        'menu_name'                  => __( 'Category', 'new-paper' ),
        'all_items'                  => __( 'All Categorys', 'new-paper' ),
        'parent_item'                => __( 'Parent Category', 'new-paper' ),
        'parent_item_colon'          => __( 'Parent Category:', 'new-paper' ),
        'new_item_name'              => __( 'New Category Name', 'new-paper' ),
        'add_new_item'               => __( 'Add New Category', 'new-paper' ),
        'edit_item'                  => __( 'Edit Category', 'new-paper' ),
        'update_item'                => __( 'Update Category', 'new-paper' ),
        'view_item'                  => __( 'View Category', 'new-paper' ),
        'separate_items_with_commas' => __( 'Separate Categorys with commas', 'new-paper' ),
        'add_or_remove_items'        => __( 'Add or remove Categorys', 'new-paper' ),
        'choose_from_most_used'      => __( 'Choose from the most used', 'new-paper' ),
        'popular_items'              => __( 'Popular Categorys', 'new-paper' ),
        'search_items'               => __( 'Search Categorys', 'new-paper' ),
        'not_found'                  => __( 'Not Found', 'new-paper' ),
        'no_terms'                   => __( 'No items', 'new-paper' ),
        'items_list'                 => __( 'vs list', 'new-paper' ),
        'items_list_navigation'      => __( 'Categorys list navigation', 'new-paper' ),
    );
    $rewrite = array(
        'slug'                       => 'video-category',
        'with_front'                 => true,
        'hierarchical'               => false,
    );
    $args = array(
        'labels'                     => $labels,
        'hierarchical'               => true,
        'public'                     => true,
        'show_ui'                    => true,
        'show_admin_column'          => true,
        'show_in_nav_menus'          => true,
        'show_categorycloud'              => true,
        'rewrite'                    => $rewrite,
    );
    register_taxonomy( 'new_paper_ntx_video_category', array( 'new_paper_ntx_video' ), $args );

}
add_action( 'init', 'regsiter_new_paper_ntx_video_category', 0 );

/*Metabox related to videos*/
add_action( 'admin_init', 'new_paper_ntx_video_metabox' );

function new_paper_ntx_video_metabox() {

    $new_paper_ntx_video_metabox = array(
        'id'          => 'new_paper_ntx_video_metabox',
        'title'       => esc_html__( 'Video Options', 'new-paper' ),
        'desc'        => '',
        'pages'       => array( 'new_paper_ntx_video' ),
        'context'     => 'normal',
        'priority'    => 'high',
        'fields'      => array(

            array(
                'id'          => 'new_paper_ntx_video_url',
                'label'       => esc_html__( 'Video URL (Youtube URL)', 'new-paper' ),
                'desc'        => 'URL of the video to (currently support youtube only)',
                'type'        => 'text'
            ),


            // gallery on-off
            array(
                'id'          => 'new_paper_ntx_enable_custom_cover',
                'label'       => esc_html__( 'Enable Custom video cover image', 'new-paper' ),
                'desc'        => esc_html__('Make sure you have uploaded the cover image via "set cover image"', 'new-paper'),
                'std'         => 'off',
                'type'        => 'on-off'
            ),


        )
    );



    /**
     * Register our meta boxes using the
     * ot_register_meta_box() function.
     */
    if ( function_exists( 'ot_register_meta_box' ) ){

        ot_register_meta_box( $new_paper_ntx_video_metabox );

    }

}
















